#!/usr/bin/env bash
set -o errexit
python -m pip install --upgrade pip
pip install -r requirements.txt
python manage.py makemigrations school
python manage.py migrate --noinput
python manage.py collectstatic --noinput
