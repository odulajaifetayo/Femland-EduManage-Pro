# Femland Imperial College — EduManage Pro (Stage 5: Subject Management)

This release continues Stage 4 and adds a subject catalogue plus class-by-class subject allocation. Existing student, teacher and class modules are retained.

## Stage 5 features
- Create, search, edit and delete subjects with unique subject codes.
- Allocate a subject to a class for a particular class/academic year.
- Assign an optional teacher to each class-subject allocation.
- Set periods per week and activate/deactivate allocations.
- Prevent duplicate allocation of the same subject to the same class.
- Django admin support for subjects and allocations.
- Staff-only access, CSRF-protected forms and pagination.

## Run locally
Python 3.10+ is required. From this folder:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python manage.py makemigrations school
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open http://127.0.0.1:8000/ and sign in with a staff account. Add teachers and classes before creating class-subject allocations.

## Upgrade from Stage 4
Replace the project files with this release while preserving your existing `db.sqlite3` file, then run `python manage.py makemigrations school` and `python manage.py migrate`. Back up the database first.

## Important
This is a development starter, not production-ready software. Use fictional data while testing. Before real school use, implement and test role-based permissions, audit logs, privacy notices, secure deployment, encrypted backups, retention rules, HTTPS and recovery procedures.

## Next stage
Stage 6: Attendance Management.
