# Render deployment notes — EduManage Pro

This package includes production-oriented Django settings for Render. Do not upload real student or staff information during testing.

## Before deployment

1. Push these updated files to the private GitHub repository.
2. In Render, create a **PostgreSQL** database and copy its **Internal Database URL** for the web service (use the External URL only if the database is accessed outside Render).
3. Create a **Web Service** from the private GitHub repository.
4. Runtime: Python. Build command: `bash build.sh`. Start command: `gunicorn config.wsgi:application`.
5. Add environment variables:
   - `DJANGO_SECRET_KEY`: a newly generated, long random secret; keep it private.
   - `DJANGO_DEBUG`: `False`
   - `DATABASE_URL`: the PostgreSQL Internal Database URL from Render.
   - `DJANGO_ALLOWED_HOSTS`: the Render hostname, e.g. `your-service.onrender.com`.
   - `CSRF_TRUSTED_ORIGINS`: the full HTTPS origin, e.g. `https://your-service.onrender.com`.
6. Deploy, then create the first staff administrator from the Render Shell with `python manage.py createsuperuser`.

## Important

- Never commit `.env`, secret keys, database files, or real student records.
- Use a private repository and restrict Render/GitHub access to trusted adults responsible for the school.
- This is a deployment configuration step, not a security audit. Before real school use, the application still needs a full review of role permissions, privacy controls, backups, audit logs, file handling, and recovery procedures.
- The build script creates the initial app migration because this project archive currently has no `school` model migration files. For ongoing development, generate and commit migrations as part of each code change rather than relying on build-time generation.
