from django.contrib import admin
from .models import Student

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ("admission_number", "last_name", "first_name", "class_level", "is_active")
    list_filter = ("class_level", "is_active", "gender")
    search_fields = ("admission_number", "first_name", "last_name", "guardian_name")
    ordering = ("last_name", "first_name")


from .models import Teacher

@admin.register(Teacher)
class TeacherAdmin(admin.ModelAdmin):
    list_display = ("employment_number", "last_name", "first_name", "subject_specialisation", "is_active")
    search_fields = ("employment_number", "first_name", "last_name", "subject_specialisation")
    list_filter = ("is_active", "gender")


from .models import SchoolClass

@admin.register(SchoolClass)
class SchoolClassAdmin(admin.ModelAdmin):
    list_display = ("level", "arm", "academic_year", "class_teacher", "room", "capacity", "is_active")
    list_filter = ("level", "academic_year", "is_active")
    search_fields = ("level", "arm", "academic_year", "class_teacher__first_name", "class_teacher__last_name")


from .models import Subject, ClassSubject

@admin.register(Subject)
class SubjectAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "is_active")
    list_filter = ("is_active",)
    search_fields = ("code", "name")

@admin.register(ClassSubject)
class ClassSubjectAdmin(admin.ModelAdmin):
    list_display = ("classroom", "subject", "teacher", "periods_per_week", "is_active")
    list_filter = ("classroom__level", "classroom__academic_year", "is_active")
    search_fields = ("subject__name", "classroom__arm", "teacher__first_name", "teacher__last_name")
