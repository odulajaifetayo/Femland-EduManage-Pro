from django import forms
from .models import Student, Teacher, SchoolClass, Subject, ClassSubject

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = [
            "admission_number", "first_name", "middle_name", "last_name",
            "date_of_birth", "gender", "class_level", "classroom", "guardian_name",
            "guardian_phone", "home_address", "admission_date", "is_active",
        ]
        widgets = {
            "date_of_birth": forms.DateInput(attrs={"type": "date"}),
            "admission_date": forms.DateInput(attrs={"type": "date"}),
            "home_address": forms.Textarea(attrs={"rows": 3}),
        }


class TeacherForm(forms.ModelForm):
    class Meta:
        model = Teacher
        fields = [
            "employment_number", "first_name", "middle_name", "last_name",
            "email", "phone", "gender", "subject_specialisation",
            "date_employed", "is_active",
        ]
        widgets = {"date_employed": forms.DateInput(attrs={"type": "date"})}


class SchoolClassForm(forms.ModelForm):
    class Meta:
        model = SchoolClass
        fields = ["level", "arm", "academic_year", "class_teacher", "room", "capacity", "is_active"]


class SubjectForm(forms.ModelForm):
    class Meta:
        model = Subject
        fields = ["code", "name", "description", "is_active"]
        widgets = {"description": forms.Textarea(attrs={"rows": 3})}


class ClassSubjectForm(forms.ModelForm):
    class Meta:
        model = ClassSubject
        fields = ["classroom", "subject", "teacher", "periods_per_week", "is_active"]
