from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from .forms import StudentForm, TeacherForm, SchoolClassForm, SubjectForm, ClassSubjectForm
from .models import Student, Teacher, SchoolClass, Subject, ClassSubject

def staff_required(view_func):
    return login_required(user_passes_test(
        lambda user: user.is_staff,
        login_url="login"
    )(view_func))

@staff_required
def student_list(request):
    query = request.GET.get("q", "").strip()
    students = Student.objects.all()
    if query:
        students = students.filter(
            Q(first_name__icontains=query) |
            Q(middle_name__icontains=query) |
            Q(last_name__icontains=query) |
            Q(admission_number__icontains=query) |
            Q(class_level__icontains=query)
        )
    paginator = Paginator(students, 15)
    page_obj = paginator.get_page(request.GET.get("page"))
    return render(request, "school/student_list.html", {
        "page_obj": page_obj, "query": query,
        "total_students": Student.objects.count(),
    })

@staff_required
def student_create(request):
    form = StudentForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        student = form.save()
        messages.success(request, f"{student.full_name} was added.")
        return redirect("student_detail", pk=student.pk)
    return render(request, "school/student_form.html", {
        "form": form, "page_title": "Register student"
    })

@staff_required
def student_detail(request, pk):
    student = get_object_or_404(Student, pk=pk)
    return render(request, "school/student_detail.html", {"student": student})

@staff_required
def student_update(request, pk):
    student = get_object_or_404(Student, pk=pk)
    form = StudentForm(request.POST or None, instance=student)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Student record updated.")
        return redirect("student_detail", pk=student.pk)
    return render(request, "school/student_form.html", {
        "form": form, "page_title": "Edit student"
    })

@staff_required
def student_delete(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == "POST":
        student.delete()
        messages.success(request, "Student record deleted.")
        return redirect("student_list")
    return render(request, "school/student_confirm_delete.html", {"student": student})


@staff_required
def teacher_list(request):
    query = request.GET.get("q", "").strip()
    teachers = Teacher.objects.all()
    if query:
        teachers = teachers.filter(
            Q(first_name__icontains=query) | Q(middle_name__icontains=query) |
            Q(last_name__icontains=query) | Q(employment_number__icontains=query) |
            Q(subject_specialisation__icontains=query)
        )
    paginator = Paginator(teachers, 15)
    page_obj = paginator.get_page(request.GET.get("page"))
    return render(request, "school/teacher_list.html", {
        "page_obj": page_obj, "query": query, "total_teachers": Teacher.objects.count()
    })

@staff_required
def teacher_create(request):
    form = TeacherForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        teacher = form.save()
        messages.success(request, f"{teacher.full_name} was added to the teacher directory.")
        return redirect("teacher_list")
    return render(request, "school/teacher_form.html", {"form": form, "page_title": "Add teacher"})

@staff_required
def teacher_update(request, pk):
    teacher = get_object_or_404(Teacher, pk=pk)
    form = TeacherForm(request.POST or None, instance=teacher)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Teacher record updated.")
        return redirect("teacher_list")
    return render(request, "school/teacher_form.html", {"form": form, "page_title": "Edit teacher"})

@staff_required
def teacher_delete(request, pk):
    teacher = get_object_or_404(Teacher, pk=pk)
    if request.method == "POST":
        teacher.delete()
        messages.success(request, "Teacher record deleted.")
        return redirect("teacher_list")
    return render(request, "school/teacher_confirm_delete.html", {"teacher": teacher})


@staff_required
def class_list(request):
    query = request.GET.get("q", "").strip()
    classes = SchoolClass.objects.select_related("class_teacher").all()
    if query:
        classes = classes.filter(Q(level__icontains=query) | Q(arm__icontains=query) | Q(academic_year__icontains=query) | Q(class_teacher__first_name__icontains=query) | Q(class_teacher__last_name__icontains=query))
    paginator = Paginator(classes, 15)
    page_obj = paginator.get_page(request.GET.get("page"))
    return render(request, "school/class_list.html", {"page_obj": page_obj, "query": query, "total_classes": SchoolClass.objects.count()})

@staff_required
def class_create(request):
    form = SchoolClassForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        classroom = form.save()
        messages.success(request, f"{classroom} was created.")
        return redirect("class_list")
    return render(request, "school/class_form.html", {"form": form, "page_title": "Create class"})

@staff_required
def class_update(request, pk):
    classroom = get_object_or_404(SchoolClass, pk=pk)
    form = SchoolClassForm(request.POST or None, instance=classroom)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Class details updated.")
        return redirect("class_list")
    return render(request, "school/class_form.html", {"form": form, "page_title": "Edit class"})

@staff_required
def class_delete(request, pk):
    classroom = get_object_or_404(SchoolClass, pk=pk)
    if request.method == "POST":
        classroom.delete()
        messages.success(request, "Class deleted. Student classroom links have been cleared; student records remain.")
        return redirect("class_list")
    return render(request, "school/class_confirm_delete.html", {"classroom": classroom})


@staff_required
def subject_list(request):
    query = request.GET.get("q", "").strip()
    subjects = Subject.objects.prefetch_related("class_allocations__classroom").all()
    if query:
        subjects = subjects.filter(Q(name__icontains=query) | Q(code__icontains=query))
    page_obj = Paginator(subjects, 15).get_page(request.GET.get("page"))
    return render(request, "school/subject_list.html", {"page_obj": page_obj, "query": query, "total_subjects": Subject.objects.count()})

@staff_required
def subject_create(request):
    form = SubjectForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        subject = form.save()
        messages.success(request, f"{subject.name} was added to the subject catalogue.")
        return redirect("subject_list")
    return render(request, "school/subject_form.html", {"form": form, "page_title": "Add subject"})

@staff_required
def subject_update(request, pk):
    subject = get_object_or_404(Subject, pk=pk)
    form = SubjectForm(request.POST or None, instance=subject)
    if request.method == "POST" and form.is_valid():
        form.save(); messages.success(request, "Subject updated."); return redirect("subject_list")
    return render(request, "school/subject_form.html", {"form": form, "page_title": "Edit subject"})

@staff_required
def subject_delete(request, pk):
    subject = get_object_or_404(Subject, pk=pk)
    if request.method == "POST":
        subject.delete(); messages.success(request, "Subject deleted; its class allocations were also removed."); return redirect("subject_list")
    return render(request, "school/subject_confirm_delete.html", {"subject": subject})

@staff_required
def allocation_list(request):
    query = request.GET.get("q", "").strip()
    allocations = ClassSubject.objects.select_related("classroom", "subject", "teacher").all()
    if query:
        allocations = allocations.filter(Q(classroom__level__icontains=query) | Q(classroom__arm__icontains=query) | Q(subject__name__icontains=query) | Q(teacher__first_name__icontains=query) | Q(teacher__last_name__icontains=query))
    page_obj = Paginator(allocations, 15).get_page(request.GET.get("page"))
    return render(request, "school/allocation_list.html", {"page_obj": page_obj, "query": query})

@staff_required
def allocation_create(request):
    form = ClassSubjectForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        allocation = form.save(); messages.success(request, f"{allocation.subject.name} assigned to {allocation.classroom}."); return redirect("allocation_list")
    return render(request, "school/allocation_form.html", {"form": form, "page_title": "Allocate subject to class"})

@staff_required
def allocation_update(request, pk):
    allocation = get_object_or_404(ClassSubject, pk=pk)
    form = ClassSubjectForm(request.POST or None, instance=allocation)
    if request.method == "POST" and form.is_valid():
        form.save(); messages.success(request, "Subject allocation updated."); return redirect("allocation_list")
    return render(request, "school/allocation_form.html", {"form": form, "page_title": "Edit subject allocation"})

@staff_required
def allocation_delete(request, pk):
    allocation = get_object_or_404(ClassSubject, pk=pk)
    if request.method == "POST":
        allocation.delete(); messages.success(request, "Subject allocation removed."); return redirect("allocation_list")
    return render(request, "school/allocation_confirm_delete.html", {"allocation": allocation})
