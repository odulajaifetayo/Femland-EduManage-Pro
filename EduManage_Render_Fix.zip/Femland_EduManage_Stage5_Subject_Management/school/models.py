from django.db import models

class Student(models.Model):
    CLASS_CHOICES = [
        ("JSS1", "JSS 1"), ("JSS2", "JSS 2"), ("JSS3", "JSS 3"),
        ("SS1", "SS 1"), ("SS2", "SS 2"), ("SS3", "SS 3"),
    ]
    GENDER_CHOICES = [("F", "Female"), ("M", "Male"), ("O", "Prefer not to say")]

    admission_number = models.CharField(max_length=30, unique=True)
    first_name = models.CharField(max_length=80)
    middle_name = models.CharField(max_length=80, blank=True)
    last_name = models.CharField(max_length=80)
    date_of_birth = models.DateField(null=True, blank=True)
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES, blank=True)
    class_level = models.CharField(max_length=4, choices=CLASS_CHOICES)
    classroom = models.ForeignKey("SchoolClass", on_delete=models.SET_NULL, null=True, blank=True, related_name="students")
    guardian_name = models.CharField(max_length=160, blank=True)
    guardian_phone = models.CharField(max_length=25, blank=True)
    home_address = models.TextField(blank=True)
    admission_date = models.DateField()
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["last_name", "first_name"]

    def __str__(self):
        return f"{self.last_name}, {self.first_name} ({self.admission_number})"

    @property
    def full_name(self):
        return " ".join(part for part in [
            self.first_name, self.middle_name, self.last_name
        ] if part)


class Teacher(models.Model):
    GENDER_CHOICES = [("F", "Female"), ("M", "Male"), ("O", "Prefer not to say")]
    employment_number = models.CharField(max_length=30, unique=True)
    first_name = models.CharField(max_length=80)
    middle_name = models.CharField(max_length=80, blank=True)
    last_name = models.CharField(max_length=80)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=25, blank=True)
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES, blank=True)
    subject_specialisation = models.CharField(max_length=120, blank=True)
    date_employed = models.DateField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["last_name", "first_name"]

    def __str__(self):
        return f"{self.last_name}, {self.first_name} ({self.employment_number})"

    @property
    def full_name(self):
        return " ".join(part for part in [self.first_name, self.middle_name, self.last_name] if part)


class SchoolClass(models.Model):
    LEVEL_CHOICES = Student.CLASS_CHOICES
    level = models.CharField(max_length=4, choices=LEVEL_CHOICES)
    arm = models.CharField(max_length=10, default="A", help_text="For example A, B or Gold")
    academic_year = models.CharField(max_length=9, help_text="For example 2026/2027")
    class_teacher = models.ForeignKey(Teacher, on_delete=models.SET_NULL, null=True, blank=True, related_name="managed_classes")
    room = models.CharField(max_length=40, blank=True)
    capacity = models.PositiveSmallIntegerField(default=40)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["academic_year", "level", "arm"]
        constraints = [models.UniqueConstraint(fields=["level", "arm", "academic_year"], name="unique_class_arm_year")]

    def __str__(self):
        return f"{self.get_level_display()} {self.arm} ({self.academic_year})"


class Subject(models.Model):
    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return f"{self.name} ({self.code})"


class ClassSubject(models.Model):
    classroom = models.ForeignKey(SchoolClass, on_delete=models.CASCADE, related_name="subject_allocations")
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name="class_allocations")
    teacher = models.ForeignKey(Teacher, on_delete=models.SET_NULL, null=True, blank=True, related_name="subject_allocations")
    periods_per_week = models.PositiveSmallIntegerField(default=3)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["classroom__level", "classroom__arm", "subject__name"]
        constraints = [models.UniqueConstraint(fields=["classroom", "subject"], name="unique_subject_per_class")]

    def __str__(self):
        return f"{self.subject.name} — {self.classroom}"
