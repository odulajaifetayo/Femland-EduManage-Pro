# Femland Imperial College — EduManage Pro (Stage 2)

This package adds the first Django backend module: staff-only student record management.

## Included
- Django authentication (staff accounts only for student pages)
- Student registration, listing, searching, details, editing and deletion
- JSS1–JSS3 and SS1–SS3 class choices
- SQLite database for local development
- Django admin interface
- CSRF protection and password validators

## Run on a computer
Install Python 3.10+ first, then in this folder run:

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
python manage.py makemigrations school
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open `http://127.0.0.1:8000/` and sign in using the superuser account. The account must be a staff user to access student records.

## Important safety and deployment notes
- This is a development starter, not a production-ready school information system.
- Use fictional data while learning. Do not upload real student or guardian details to an unreviewed prototype.
- Before real use, obtain the school's authorization and implement appropriate privacy notices, access policies, audit logs, backups, retention rules, HTTPS, secret management, database protection and tested recovery.
- Set a strong private `DJANGO_SECRET_KEY`, `DJANGO_DEBUG=False`, and a correct `DJANGO_ALLOWED_HOSTS` before deployment.
- For production, use PostgreSQL and a reputable host. Do not expose SQLite or the development server publicly.
- The current staff permission check is a first step. Add separate, least-privilege roles (e.g. registrar, teacher, bursar) and restrict fields/actions before school deployment.
- Deletions should be reviewed against the school's records-retention policy.

## Next modules
Teacher records, class/subject setup, attendance, assessments/results, report cards, fees, guardian portal, role-specific permissions, audit trail and automated backups.
