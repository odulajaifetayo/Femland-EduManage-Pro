from django.contrib import admin
from .models import Student

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ("admission_number", "last_name", "first_name", "class_level", "is_active")
    list_filter = ("class_level", "is_active", "gender")
    search_fields = ("admission_number", "first_name", "last_name", "guardian_name")
    ordering = ("last_name", "first_name")


from .models import Teacher

@admin.register(Teacher)
class TeacherAdmin(admin.ModelAdmin):
    list_display = ("employment_number", "last_name", "first_name", "subject_specialisation", "is_active")
    search_fields = ("employment_number", "first_name", "last_name", "subject_specialisation")
    list_filter = ("is_active", "gender")
