from django import forms
from .models import Student, Teacher

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = [
            "admission_number", "first_name", "middle_name", "last_name",
            "date_of_birth", "gender", "class_level", "guardian_name",
            "guardian_phone", "home_address", "admission_date", "is_active",
        ]
        widgets = {
            "date_of_birth": forms.DateInput(attrs={"type": "date"}),
            "admission_date": forms.DateInput(attrs={"type": "date"}),
            "home_address": forms.Textarea(attrs={"rows": 3}),
        }


class TeacherForm(forms.ModelForm):
    class Meta:
        model = Teacher
        fields = [
            "employment_number", "first_name", "middle_name", "last_name",
            "email", "phone", "gender", "subject_specialisation",
            "date_employed", "is_active",
        ]
        widgets = {"date_employed": forms.DateInput(attrs={"type": "date"})}
