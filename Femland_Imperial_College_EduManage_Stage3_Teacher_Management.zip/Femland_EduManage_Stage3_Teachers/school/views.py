from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from .forms import StudentForm, TeacherForm
from .models import Student, Teacher

def staff_required(view_func):
    return login_required(user_passes_test(
        lambda user: user.is_staff,
        login_url="login"
    )(view_func))

@staff_required
def student_list(request):
    query = request.GET.get("q", "").strip()
    students = Student.objects.all()
    if query:
        students = students.filter(
            Q(first_name__icontains=query) |
            Q(middle_name__icontains=query) |
            Q(last_name__icontains=query) |
            Q(admission_number__icontains=query) |
            Q(class_level__icontains=query)
        )
    paginator = Paginator(students, 15)
    page_obj = paginator.get_page(request.GET.get("page"))
    return render(request, "school/student_list.html", {
        "page_obj": page_obj, "query": query,
        "total_students": Student.objects.count(),
    })

@staff_required
def student_create(request):
    form = StudentForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        student = form.save()
        messages.success(request, f"{student.full_name} was added.")
        return redirect("student_detail", pk=student.pk)
    return render(request, "school/student_form.html", {
        "form": form, "page_title": "Register student"
    })

@staff_required
def student_detail(request, pk):
    student = get_object_or_404(Student, pk=pk)
    return render(request, "school/student_detail.html", {"student": student})

@staff_required
def student_update(request, pk):
    student = get_object_or_404(Student, pk=pk)
    form = StudentForm(request.POST or None, instance=student)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Student record updated.")
        return redirect("student_detail", pk=student.pk)
    return render(request, "school/student_form.html", {
        "form": form, "page_title": "Edit student"
    })

@staff_required
def student_delete(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == "POST":
        student.delete()
        messages.success(request, "Student record deleted.")
        return redirect("student_list")
    return render(request, "school/student_confirm_delete.html", {"student": student})


@staff_required
def teacher_list(request):
    query = request.GET.get("q", "").strip()
    teachers = Teacher.objects.all()
    if query:
        teachers = teachers.filter(
            Q(first_name__icontains=query) | Q(middle_name__icontains=query) |
            Q(last_name__icontains=query) | Q(employment_number__icontains=query) |
            Q(subject_specialisation__icontains=query)
        )
    paginator = Paginator(teachers, 15)
    page_obj = paginator.get_page(request.GET.get("page"))
    return render(request, "school/teacher_list.html", {
        "page_obj": page_obj, "query": query, "total_teachers": Teacher.objects.count()
    })

@staff_required
def teacher_create(request):
    form = TeacherForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        teacher = form.save()
        messages.success(request, f"{teacher.full_name} was added to the teacher directory.")
        return redirect("teacher_list")
    return render(request, "school/teacher_form.html", {"form": form, "page_title": "Add teacher"})

@staff_required
def teacher_update(request, pk):
    teacher = get_object_or_404(Teacher, pk=pk)
    form = TeacherForm(request.POST or None, instance=teacher)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Teacher record updated.")
        return redirect("teacher_list")
    return render(request, "school/teacher_form.html", {"form": form, "page_title": "Edit teacher"})

@staff_required
def teacher_delete(request, pk):
    teacher = get_object_or_404(Teacher, pk=pk)
    if request.method == "POST":
        teacher.delete()
        messages.success(request, "Teacher record deleted.")
        return redirect("teacher_list")
    return render(request, "school/teacher_confirm_delete.html", {"teacher": teacher})
